/**
 * 
 * Here are the JQuery (and JQuery UI) assignments:

 PART 1: 
I want two (jQuery UI sortable) lists displayed in a box. xxx
The list on the left should be green xxx
The list on the right should be red xxx
I want to be able to drag items between the list and when I do their color should update. xxx
I want to be able to remove items from the list by dragging them outside of the box. xxxxxx
I want to be able to add items to either list. xxxxx


PART 2:
Create a table of users
I want the table to display Name, Email, and Password. xxxx
I want to be able to add users to the table with a create new user button. xxx
This button should open a modal that has input fields for the above fields. xxx
This modal should be draggable and resizable. xxx
I want validation on the fields, they should be at least 3 characters long and emails must include @
 * 
 * 
 */



var flag = 0;
$(document).ready(function()
{
    $( "#sortable-1,#sortable-2" ).sortable({
        receive: function(event, ui){flag = 0},
        over:function(event, ui){flag = 0},
        out:function(event, ui){ flag = -1},
        
        beforeStop:function(event,ui)
        {
            if(flag == -1)
            {
                ui.item.remove();
            }
        }, 
        connectWith: "#sortable-1,#sortable-2",
    })
})

function addGreen()
{
    var li1 = '<li>';
    var li2 = '</li>';
    var text = $('#inputBox').val();
    var liFinal = li1 + text + li2;

    $("#sortable-1").append(liFinal);
}

function addRed()
{
    var li1 = '<li>';
    var li2 = '</li>';
    var text = $('#inputBox').val();
    var liFinal = li1 + text + li2;

    $("#sortable-2").append(liFinal);
}




//Part 2
//Set up the dialog box
var counter = 1;
var flag = 0;

$(document).ready(function()
{

    $("#myForm").submit(function(e) {
        e.preventDefault();
        insetToTable();
        $('#myDialog').dialog('close');
        
    });

    $("#myDialog").dialog({
        autoOpen  : false,
        modal     : true,
    });
    
    //Open the dialog box when the button is clicked.
    $('#createU').click(function() {
        $("#myDialog").dialog("open");
    });

}
)

function insetToTable()
{
    var name = $('#name').val();
    var email = $('#email').val();
    var password = $('#password').val();

    var tr = '<tr>';
    var tr2 = '</tr>';

    var td = '<td>';
    var td2 = '</td>';

    var counttd = td+counter+td2;
    var nametd = td+name+td2;
    var emailtd = td+email+td2;
    var passwordtd = td+password+td2;

    var trfinal = tr+counttd+nametd+emailtd+passwordtd+tr2;

    $("#usertb").append(trfinal);

    counter++;
}

/*

                  var name = $('#name').val();
                    var email = $('#email').val();
                    var password = $('#password').val();

                      while(flag == 0)
                      {
                        alert(name.length + ' ' + email.length + ' ' + password.length);

                        if(name.length >= 3 && email.length >= 3 && password >= 3)
                        {
                            var ch = email.search('@');
                            if( ch != -1 )
                            {
                            flag = 1;
                            insetToTable(name,email,password,counter);
                            }
                        }
                        else
                        {
                            alert(name.length + ' ' + email.length + ' ' + password.length);


                            $('#name').val("");
                            $('#email').val("");
                            $('#password').val("");

                            alert('incorrect length! need at least 3 characters for all or Email does not have @ included!');
                            $(this).dialog('close');

                            break;
                        }
                      }

                      //alert('Name: ' + name + '\nEmail: ' + email + '\nPassword: ' + password );



*/