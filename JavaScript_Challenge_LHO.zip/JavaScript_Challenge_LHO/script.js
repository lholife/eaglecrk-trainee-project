/*
* PART1:  Create a button to alert the current date. xxxxx
*  PART2: Display the data from this  xxxxxx
link: https://api.nasa.gov/planetary/apod?api_key=jT9a9djmlXvr6QGYLXet52uTP4ycNUGYnqdQeCA7 
It should display today's data by default
Please display the Title, Description, Image, the image name, and the person that took the picture.
I want to be able to request information on other dates.
*  PART 3
Create a calendar
Display all the days of the current month
Display the current date differently
Gray out the days outside of the month
 */


//PART 1 ========


function myInit()
{
  defaultData();
  calender();
}

function getCurrentDate()
{
   var date = new Date();
   alert(date);
   document.getElementById("currentData").innerHTML = date;
    
}


//Part 2 ========
// populate table with default date
 function defaultData()
 {

    
var request = new XMLHttpRequest()

request.open('GET',
'https://api.nasa.gov/planetary/apod?api_key=jT9a9djmlXvr6QGYLXet52uTP4ycNUGYnqdQeCA7',true)
request.onload = function() {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response)

  if (request.status >= 200 && request.status < 400) {
    
      document.getElementById("title").innerHTML = data.title
      document.getElementById("desc").innerHTML = data.explanation;
      document.getElementById("image").innerHTML = '<img src="' + data.hdurl + '">';
      document.getElementById("imageTitle").innerHTML = data.title;
      document.getElementById("author").innerHTML = data.copyright;
      document.getElementById("dateDisplay").innerHTML = data.date;
    
  } else {
    alert("Cannot be retrieve!!!")
  }
}
request.send()


 }

//populate table with the new date input
 function getNewData()
 {
var date2 = '&date=';
var date3 = document.getElementById("newDate").value;
var mash = date2+date3;

var request = new XMLHttpRequest()

var key ="https://api.nasa.gov/planetary/apod?api_key=jT9a9djmlXvr6QGYLXet52uTP4ycNUGYnqdQeCA7";
key+=mash;

request.open('GET',
key, true)
request.onload = function() {

  // Begin accessing JSON data here
  var data = JSON.parse(this.response)


document.onload

  if (request.status >= 200 && request.status < 400) {
    
      document.getElementById("title").innerHTML = data.title
      document.getElementById("desc").innerHTML = data.explanation;
      document.getElementById("image").innerHTML = '<img src="' + data.hdurl + '">';
      document.getElementById("imageTitle").innerHTML = data.title;
      document.getElementById("author").innerHTML = data.copyright;
      document.getElementById("dateDisplay").innerHTML = data.date;
    
  } else {
    alert("Cannot be retrieve!!!")
  }
}

request.send()

 }



































 //PART 3 ========

 var monthList = [
  'jan', //31
  'feb', // 28 (29 leap year)
  'mar', // 31
  'apr', // 30
  'may', // 31
  'jun', // 30
  'jul', // 31
  'aug', // 31
  'sep', //30
  'oct', // 31
  'nov', // 30
  'dec' // 31
 ];

 var dayList = [
  'sun',
  'mon',
  'tue',
  'wed',
  'thu',
  'fri',
  'sat'
];

 function calender()
 {
   currentDate();

 }

function currentDate()
{
  var year;
  var month;
  var day;
  var dayNum;

  //var date = new Date(2019,10,19);
  var date = new Date();
  
  year = date.getFullYear();
  month = date.getMonth();
  day = date.getDay();
  dayNum = date.getDate();

  monthStructure(dayNum,month,date);
  yearDisplay(year);
  monthDisplay(month);
  dayDisplay(day);
  dateDisplay(dayNum,date);
}

// display year
 function yearDisplay(year)
{
     if (yearIncrem > 11)
     {
         monthKeeper.setFullYear(year);
     }
   document.getElementById("yid").innerHTML = year;
 }

// display month
 function monthDisplay(month)
 {

  for(var i = 0; i < monthList.length; i++)
  {

    if(i == month)
    {
      document.getElementById(monthList[i]).style.backgroundColor = 'lightgreen';
      break;
    }
  }
 }

 // highlight the word of the week
 function dayDisplay(day)
 {
  for(var i = 0; i < dayList.length; i++)
  {
    if(i == day)
    {
      document.getElementById(dayList[i]).style.backgroundColor = 'lightgreen';
      break;
    }
  }
 }

 var dataD = 0;
 // higlight the current day.
 function dateDisplay(day,date)
 {

  var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  var wordPlacement = firstDay.getDay();

     // get rid of old background cell
  for (var i = 1; i < 32; i++)
  {
      if (i == dateOld) {
          
          dateOld = dataD;
          document.getElementById(dateOld.toString()).style.backgroundColor = "white";
         
      }
  }
     // put new background for new cell
  for(var i = 1; i < 32; i++)
  {
   
    if(i == day)
    {
        i += wordPlacement;
        dataD = i;
      tempStr = i.toString();
      document.getElementById(tempStr).style.backgroundColor = 'lightgreen';
    }

  }

 }



 var day1 = 29; //28
 var day2 = 30; //29
 var day3 = 31; //30
 var day4 = 32; //31
 var leapYear = 0;

 function monthStructure(day,month,date)
 {
    // 30 days
  if(month == 3 || 5 || 8 || 10 )
  {
    weekStructure(day,month,date);

  }
  // 28 days or 29
  if(month == 1)
  {
    var tempy = date.getFullYear();
    //Check if leap year
    if(tempy % 4 == 0)
    {
        leapYear = 1;
        weekStructure(day, month, date);
    }
    else {
        leapYear = 0;
        weekStructure(day, month, date);
    }

  }
  //31 days
  if(month ==  0 || 2 || 4 || 6 || 7 || 9 || 11)
  {
    weekStructure(day,month,date);
  }
 }



// creating the structure for the weeks
 
 function weekStructure(day,month,date)
 {
var tempNum = 0;
    
     // determining how many days for the month
  if(month == 3 || month == 5 || month == 8 || month == 10 )
  {
    tempNum = day3;
  }

  if(month == 0 || month == 2 || month == 4 || month == 6 || month == 7 || month == 9 || month == 11)
  {
    tempNum = day4;
  }

  if (month == 1) {
      if (leapYear == 1)
      {
          tempNum = day2;
      }
      else
      {
          tempNum = day1;
      }
      
  }

  // populating the weeks
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    var placements = firstDay.getDate();
    var wordPlacement = firstDay.getDay();

    var flag = 0;
    var tempStr;

    // starting date
      for(var i = 0; i < 8; i++)
      {
        if(wordPlacement == i)
        {
          wordPlacement++;
          tempStr = wordPlacement.toString();
              document.getElementById(tempStr).innerHTML = placements;
              wordPlacement = firstDay.getDay();
              break;
        }
      }

     //empty the table calender
      for (var i = 1; i < 43; i++) {
          var tempStr = i.toString();

           document.getElementById(tempStr).innerHTML = "";
          
      }
      
     //populate the calender
      for(var i = 1; i < tempNum; i++)
      {
          wordPlacement++;
          tempStr = wordPlacement.toString();
          document.getElementById(tempStr).innerHTML = placements;
          placements++;
      }


     // get the amount of empty cells
      var emptyChecker = -1;
      for(var i = 1; i < 8; i++)
      {
        var tempStr = i.toString();
        if(document.getElementById(tempStr).innerHTML == "")
        {
            emptyChecker++;
        }
      }

     // remove old grey cellls
      for (var i = 1; i < 36; i++) {
          var tempStr = i.toString();

          if (document.getElementById(tempStr).style.backgroundColor == "lightgrey") {
              document.getElementById(tempStr).style.backgroundColor = "white";
          }
      }
      
      beforeMonths(emptyChecker, date);
      afterMonths(date);


  
 }

// populate the before the current month
 function beforeMonths(emptyChecker, date)
 {
    
    

     //before month populated
     var monthbefore = new Date(date.getFullYear(), date.getMonth(),  -emptyChecker);
     emptyChecker = -1;

     
     
     var tempNum1 = monthbefore.getDate();

     

    for (var i = 1; i < 43; i++) {
    var tempStr = i.toString();

    if (document.getElementById(tempStr).style.backgroundColor == "lightgrey")
    {
        document.getElementById(tempStr).style.backgroundColor = "white";
    }
    }

     for (var i = 1; i < 9; i++) {
         var tempStr = i.toString();
         if (document.getElementById(tempStr).innerHTML == "") {

             document.getElementById(tempStr).innerHTML = tempNum1;
             document.getElementById(tempStr).style.backgroundColor = "lightgrey";
             tempNum1++;
         }
     }

 }

// populate after the month
 function afterMonths(date)
 {
     for (var i = 15; i < 43; i++) {
         var tempStr = i.toString();

         if (document.getElementById(tempStr).style.backgroundColor == "lightgrey") {
             document.getElementById(tempStr).style.backgroundColor = "white";
         }
     }


     //after month populated
     var monthafter = new Date(date.getFullYear(), date.getMonth() + 1, 1);
     var tempNum2 = monthafter.getDate();
     for (var i = 30; i < 43; i++) {
         var tempStr = i.toString();
         if (document.getElementById(tempStr).innerHTML == "") {
             document.getElementById(tempStr).innerHTML = tempNum2;
             document.getElementById(tempStr).style.backgroundColor = "lightgrey";
             tempNum2++;
         }
     }
 }


 var monthKeeper = new Date();;
 var yearIncrem = 0;

 var monthOld;
 var dayOld;
 var yearOld = 0;
 var dateOld;

 function forwardMonth() {

     if (yearIncrem > 11)
     {
         yearIncrem = 0;
     }

  
     // get old month and remove the background of previous month
     yearIncrem = monthKeeper.getMonth();
     dayOld = monthKeeper.getDay();
     monthOld = yearIncrem;
     dateOld = monthKeeper.getDate();
     document.getElementById(dayList[dayOld]).style.backgroundColor = 'white';
     document.getElementById(monthList[monthOld]).style.backgroundColor = 'white';

     //alert(dateOld);
     //document.getElementById(dateOld.toString()).style.backgroundColor = "white";

     yearIncrem++;

     // set new month
     monthKeeper.setMonth(yearIncrem);

     var year;
     var month;
     var day;
     var dayNum;

     year = monthKeeper.getFullYear();
     month = monthKeeper.getMonth();
     day = monthKeeper.getDay();
     dayNum = monthKeeper.getDate();

     yearDisplay(year);
     monthDisplay(month);
     dayDisplay(day);
     dateDisplay(dayNum, monthKeeper);
     monthStructure(dayNum, month, monthKeeper);


 }

 function backwardMonth() {
     if (yearIncrem < 0) {
         yearIncrem = 11;
     }


     // get old month and remove the background of previous month
     yearIncrem = monthKeeper.getMonth();
     dayOld = monthKeeper.getDay();
     monthOld = yearIncrem;
     dateOld = monthKeeper.getDate();
     document.getElementById(dayList[dayOld]).style.backgroundColor = 'white';
     document.getElementById(monthList[monthOld]).style.backgroundColor = 'white';

     yearIncrem--;

     // set new month
     monthKeeper.setMonth(yearIncrem);

     var year;
     var month;
     var day;
     var dayNum;

     year = monthKeeper.getFullYear();
     month = monthKeeper.getMonth();
     day = monthKeeper.getDay();
     dayNum = monthKeeper.getDate();

     yearDisplay(year);
     monthDisplay(month);
     dayDisplay(day);
     dateDisplay(dayNum, monthKeeper);
     monthStructure(dayNum, month, monthKeeper);
 }
